package com.practice.bollywoodservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BollywoodServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
