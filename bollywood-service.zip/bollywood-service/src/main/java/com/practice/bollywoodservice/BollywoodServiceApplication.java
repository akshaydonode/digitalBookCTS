package com.practice.bollywoodservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BollywoodServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BollywoodServiceApplication.class, args);
	}

}
